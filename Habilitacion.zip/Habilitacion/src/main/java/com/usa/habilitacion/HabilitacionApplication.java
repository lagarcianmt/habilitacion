package com.usa.habilitacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HabilitacionApplication {

    public static void main(String[] args) {
        SpringApplication.run(HabilitacionApplication.class, args);
    }

}
